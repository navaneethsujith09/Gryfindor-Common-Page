function score_charms()
{
  var score=0;
  if(document.getElementById("element_3_2").checked)
  {
    score+=1;
  }
  if(document.getElementById("element_4").value==1)
  {
    score+=1;
  }
  if(document.getElementById("element_5_3").checked&&document.getElementById("element_5_2").checked&&document.getElementById("element_5_4").checked)
  {
    score+=1;
  }
  squishy=document.getElementById("element_2").value;
  squishy=squishy.toLocaleLowerCase();
  if(squishy=="softening")
  {
    score+=1;
  }
  score_charms="Your Charms Score is ".concat(score);
  alert(score_charms);
}

function score_history()
{
  alert();
  var score=0;
  if(document.getElementById("element_3_2").checked)
  {
    score+=1;
  }
  if(document.getElementById("element_4").value==1)
  {
    score+=1;
  }
  if(document.getElementById("element_5_2").checked)
  {
    score+=1;
  }
  evil=document.getElementById("element_2").value;
  evil=squishy.toLocaleLowerCase();
  if(evil=="evil")
  {
    score+=1;
  }
  score_history="Your History of Magic Score is ".concat(score);
  alert(score_charms)
}
