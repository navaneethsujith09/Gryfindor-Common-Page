  function validate_form ()
  {
   var i;
   var user=document.forms["form_117838"]["element_1"].value;
   for(i=1;i<=4;i++)
   {
     var string="element_3_".concat(i);
     var house=document.forms["form_117838"][string].checked;
     if(house==true)
     {
       break;
     }
     else
     {
       house=null;
     }
   }
    for(i=1;i<=6;i++)
   {
     string="element_5_".concat(i);
     var spell=document.forms["form_117838"][string].checked;
     if(spell==true)
     {
       break;
     }
     else
     {
       spell=null
     }
   }
   var edible=document.forms["form_117838"]["element_4"].value;
   var team=document.forms["form_117838"]["element_2"].value;
   alert(user);
   alert(house);
   alert(edible);
   alert(spell);
   alert(team);
  if(user==""||user==null||house==null||edible==null||spell==""||spell==null||team==null||team=="")
  {
    document.getElementById("error").innerHTML="Required field must be filled out";
    return false; 
  }
}