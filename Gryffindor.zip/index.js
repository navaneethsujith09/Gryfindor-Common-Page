var password = prompt("The Fat Lady screams \"password!\" Hint: The password is the last name of previous headmaster of Hogwarts");
password.toLocaleLowerCase()
if (password == "dumbledore"||password=="Dumbledore"){
  alert("You're correct! Welcome to the Gryffindor Home Page!");
}
else {
  alert("It seems that you are from another house or you have forgotten the password. But, no problem! You may enter after you fill out this form.");
  location.href="form.html";
}
