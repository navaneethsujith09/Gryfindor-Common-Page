var password = prompt("You must prove that you are a first year in the Gryffindor House. Password:");
password.toLowerCase()

if (password == "dumbledore"||"Dumbledore"){
  alert("You're correct! Lets start our learning journey.");
}
else {
  alert("Password is incorrect");
  location.href="home.html";
}