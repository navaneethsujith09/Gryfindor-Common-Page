

// function students_show()
// {
//   document.getElementById("meme").className="show";
// }
//  function students_hide()
//  {
//    document.getElementById("meme").className="hide";
//  }

// function prefects_show()
// {
//   document.getElementById("prefects").className="show";
//   document.getElementById("prefect_title").className="show";
// }
//  function prefects_hide()
//  {
//    document.getElementById("prefects").className="hide";
//   document.getElementById("prefect_title").className="hide";
//  }